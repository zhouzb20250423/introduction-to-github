import hashlib


from flask import Flask, jsonify, request


def get_user_dict():
    info_dict = {}
    with open("db.txt", mode="r", encoding="UTF-8") as f:
        for line in f:
            line = line.strip()
            token, name = line.split(",")
            info_dict[token] = name
    return info_dict


app = Flask(__name__)
"""

"""

@app.route('/bili', methods=['POST'])
def bili():

    token = request.args.get("token")
    if not token:
        return jsonify({"status": False, 'error': "no token"})

    user_dict = get_user_dict()
    if token not in user_dict:
        return jsonify({"status": False, 'error': "no token"})

    ordered_string = request.json.get("ordered_string")
    if not ordered_string:
        return jsonify({"status": False, 'error': "no data"})

    encrypy_string = ordered_string + "560c52ccd288fed045859ed18bffd973"
    obj = hashlib.md5(encrypy_string.encode('UTF-8'))
    sign = obj.hexdigest()
    # get json request
    print(request.json)
    return jsonify({"status": True, "data": sign})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
