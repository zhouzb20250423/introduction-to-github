from safetensors import safe_open
import torch

weight_path = 'my_fake_checkpoint.safetensors'


def analyze_weights(weight_path):
    with safe_open(weight_path, framework="pt") as f:
        print("=" * 50)
        print("权重键名结构分析（前20个键）：")
        print("=" * 50)
        for i, key in enumerate(list(f.keys())[:20]):  # 打印前20个键
            tensor = f.get_tensor(key)
            print(f"{i + 1}. {key} | 形状: {tensor.shape} | 类型: {tensor.dtype}")

        print("\n" + "=" * 50)
        print("权重结构总结：")
        print("=" * 50)

        # 自动推断模型参数
        layer_types = {}
        for key in f.keys():
            parts = key.split('.')
            layer_name = parts[-2] if len(parts) > 1 else parts[-1]
            layer_types[layer_name] = layer_types.get(layer_name, 0) + 1

        print("\n层类型统计：")
        for layer, count in layer_types.items():
            print(f"{layer}: {count}处")

        # 检查是否存在特殊结构
        has_attention = any("attention" in k.lower() for k in f.keys())
        print(f"\n是否包含注意力层: {has_attention}")


# 使用示例
analyze_weights("my_fake_checkpoint.safetensors")
