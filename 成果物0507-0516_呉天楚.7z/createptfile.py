import torch
from safetensors.torch import save_file

# 创建一个权重张量
position_embedding_weight = torch.randn(77, 768, dtype=torch.float16)

# 定义字典，键为嵌套式权重名
state_dict = {
    "conditioner.embedders.0.transformer.text_model.embeddings.position_embedding.weight": position_embedding_weight
}

# 保存为 PyTorch checkpoint 格式
torch.save(state_dict, "my_fake_checkpoint.pt")
save_file(state_dict, "my_fake_checkpoint.safetensors")

print("保存完成 ✅")

# .pt 文件
loaded = torch.load("my_fake_checkpoint.pt")
print(loaded.keys())

# .safetensors 文件
from safetensors.torch import load_file

loaded_safe = load_file("my_fake_checkpoint.safetensors")
print(loaded_safe.keys())
