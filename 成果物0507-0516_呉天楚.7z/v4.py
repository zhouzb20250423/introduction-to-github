import hashlib
import time
import dbutils
import pyodbc
from dbutils.pooled_db import PooledDB

from flask import Flask, jsonify, request


POOL=PooledDB(
    creator=pyodbc,
    mincached=1,    # 最小连接数
    maxcached=5,    #  最大闲置连接数
    maxshared=5,    #  最大共享连接数
    maxconnections=5,   #  最大连接数
    blocking=True,  #  如果连接池已满，是否阻塞等待
    ping=7,         #  ping检查间隔，单位秒，默认为0，表示不检查
    creator_args=(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=localhost;'  # 或者使用 .\SQLEXPRESS 如果使用Express版本
        'DATABASE=Daichigigen;'
        'UID=active_user01;'  # 如果是Windows身份验证，可以省略
    )
)

def get_user_dict():
    info_dict = {}
    with open("db.txt", mode="r", encoding="UTF-8") as f:
        for line in f:
            line = line.strip()
            token, name = line.split(",")
            info_dict[token] = name
    return info_dict

def fetch_one(sql,params):
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=localhost;'  # 或者使用 .\SQLEXPRESS 如果使用Express版本
        'DATABASE=Daichigigen;'
        'UID=active_user01;'  # 如果是Windows身份验证，可以省略
        'PWD=Aa111111'  # 如果是Windows身份验证，可以省略
    )
    # 创建游标
    print("Connected to SQL Server!")
    time.sleep(5)
    cursor = conn.cursor()
    # 参数化查询（推荐方式）

    cursor.execute(sql, params)
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return  result
app = Flask(__name__)
"""

"""


@app.route('/bili', methods=['POST'])
def bili():
    # check token if empty
    token = request.args.get("token")
    if not token:
        return jsonify({"status": False, 'error': "no token"})

    # check token if legal and connect to database




    #user_dict = get_user_dict()
    result= fetch_one("SELECT * FROM [dbo].[Users] WHERE [token] = ?", (token,))

    if not result:
        return jsonify({"status": False, 'error': "no token"})

    ordered_string = request.json.get("ordered_string")
    if not ordered_string:
        return jsonify({"status": False, 'error': "no data"})

    encrypy_string = ordered_string + "560c52ccd288fed045859ed18bffd973"
    obj = hashlib.md5(encrypy_string.encode('UTF-8'))
    sign = obj.hexdigest()
    # get json request
    print(request.json)
    return jsonify({"status": True, "data": sign})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
