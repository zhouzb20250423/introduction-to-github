import json
from math import trunc

from flask import Flask, request,jsonify

app = Flask(__name__)


# 下記のアドレスを入力したら、関数を作用する。
# ?name=Jenny&sex=female
# GET REQUESTS
# json {"xx":123,"yy":"abc"}
@app.route("/index", methods=["POST", "GET"])
def hello():
    # name = request.args.get("name")
    # sex = request.args.get("sex")
    # print(name, sex)
    #
    # xx = request.form.get("xx")
    # yy = request.form.get("yy")

    # print(xx, yy)
    # type(request.json)
    #print(request.json)
    return jsonify({"status:": True, 'data': "abc"})


@app.route("/xjr2")
def hello2():
    return "Hello World2!"


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
