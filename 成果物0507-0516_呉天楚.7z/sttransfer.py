# from mymodel import MyModel
#
#
# def validate_structure():
#     model = MyModel()
#     total_params = sum(p.numel() for p in model.parameters())
#     print(f"总参数量: {total_params / 1e6:.1f}M")
#
#     # 检查关键层形状
#     text_model = model.conditioner.embedders[0].transformer.text_model
#     assert text_model.embeddings.token_embedding.weight.shape == (49408, 768)
#     assert text_model.encoder.layers[0].mlp.fc1.weight.shape == (3072, 768)
#     print("✅ 结构验证通过")
#
#
# validate_structure()

#data/zukiNewCuteILL_newV20.safetensors
# from mymodel import MyModel
#
#
# def load_weights(model, weight_path):
#     from safetensors import safe_open
#
#     state_dict = {}
#     with safe_open(weight_path, framework="pt") as f:
#         for key in f.keys():
#             # 键名转换示例（如需适配自定义结构）
#             new_key = key.replace("conditioner.embedders.0.", "")
#             state_dict[new_key] = f.get_tensor(key)
#
#     model.load_state_dict(state_dict, strict=True)
#     print("权重加载成功")
#
#
# model = MyModel()
# load_weights(model, "data/zukiNewCuteILL_newV20.safetensors")
