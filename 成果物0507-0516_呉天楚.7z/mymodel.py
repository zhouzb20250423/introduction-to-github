import torch
import torch.nn as nn
from safetensors import safe_open


class TextEmbeddings(nn.Module):
    def __init__(self):
        super().__init__()
        # 精确匹配权重形状
        self.token_embedding = nn.Embedding(49408, 768)  # 来自权重形状[49408,768]
        self.position_embedding = nn.Embedding(77, 768)  # 来自权重形状[77,768]

        # 必须注册为buffer（非可训练参数）
        self.register_buffer("position_ids", torch.arange(77).expand((1, -1)))


class TransformerAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.q_proj = nn.Linear(768, 768)
        self.k_proj = nn.Linear(768, 768)
        self.v_proj = nn.Linear(768, 768)
        self.out_proj = nn.Linear(768, 768)


class TransformerMLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(768, 3072)  # 权重形状[3072,768]
        self.fc2 = nn.Linear(3072, 768)  # 权重形状[768,3072]


class TransformerLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer_norm1 = nn.LayerNorm(768)
        self.layer_norm2 = nn.LayerNorm(768)
        self.self_attn = TransformerAttention()
        self.mlp = TransformerMLP()


class TransformerEncoder(nn.Module):
    def __init__(self, num_layers=12):
        super().__init__()
        self.layers = nn.ModuleList([TransformerLayer() for _ in range(num_layers)])


class TextModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.embeddings = TextEmbeddings()
        self.encoder = TransformerEncoder()


class Transformer(nn.Module):
    def __init__(self):
        super().__init__()
        self.text_model = TextModel()


class Embedder(nn.Module):
    def __init__(self):
        super().__init__()
        self.transformer = Transformer()


class Conditioner(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedders = nn.ModuleList([Embedder()])  # 根据权重只有embedder.0


class MyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.conditioner = Conditioner()


# 初始化并验证
model = MyModel()


# 精确键名映射加载
def load_weights(model, weight_path):
    state_dict = {}
    with safe_open(weight_path, framework="pt") as f:
        for key in f.keys():
            # 保持原始键名不变
            state_dict[key] = f.get_tensor(key)

    # 特殊处理position_ids（确保类型匹配）
    if "conditioner.embedders.0.transformer.text_model.embeddings.position_ids" in state_dict:
        model.conditioner.embedders[0].transformer.text_model.embeddings.register_buffer(
            "position_ids",
            state_dict["conditioner.embedders.0.transformer.text_model.embeddings.position_ids"].long()
        )
        del state_dict["conditioner.embedders.0.transformer.text_model.embeddings.position_ids"]

    # 严格加载
    model.load_state_dict(state_dict, strict=True)
    print("✅ 权重加载成功")


load_weights(model, "data/zukiNewCuteILL_newV20.safetensors")