import hashlib
import json
from math import trunc

from flask import Flask, request, jsonify

app = Flask(__name__)


# 下記のアドレスを入力したら、関数を作用する。
# ?name=Jenny&sex=female
# GET REQUESTS
# json {"xx":123,"yy":"abc"}
@app.route("/bili", methods=["POST"])
def bili():

    """
    data format{"":""}
    :return:
    """
    ordered_string= request.json.get()
    if not ordered_string:
        return jsonify({"status": False, 'error': "no data"})

    encrypy_string = ordered_string + "560c52ccd288fed045859ed18bffd973"
    obj = hashlib.md5(encrypy_string.encode('UTF-8'))
    sign = obj.hexdigest()
    # get json request
    print(request.json)
    return jsonify({"status": True, "data": sign})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
